from setuptools import find_packages, setup
setup(name='gazebo_msgs', version='2.5.20.post0', packages=find_packages(),
      install_requires=['genpy<2000'])